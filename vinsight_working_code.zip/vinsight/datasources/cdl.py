import ee

CDL_COLLECTION_PATH = 'USDA/NASS/CDL'

def get_scale(region):
    acres = region.geometry().area(0.001,'EPSG:32611').multiply(0.000247105).getInfo()
    return 30 if acres < 1000000 else 300

def get_crop_vectors_for_geom(geom, crop_id=69, scale=30, historic_years=4):
    """Given a geometry, return a feature collection representing requested crop.

    Args:
        geom: A geometry
        crop_id: attribute identifier for crop type. Default: 69
        scale: The scale at which to yield the CDL layer
    Returns:
        ee.FeatureCollection
    """
    #// Load yearly grape classifications.
    cdl_collection = ee.ImageCollection(CDL_COLLECTION_PATH)
    f = lambda image: image.select('cropland').clip(geom).updateMask(image.select('cropland').eq(crop_id))
    cdl_collection = cdl_collection.map(f)
    #// Take common area (intersection) of layers from 2007 - 2015 (max: 8)
    cdl = cdl_collection.limit(maximum = historic_years, opt_property = 'system:index', opt_ascending = False)
    count = cdl.reduce(ee.Reducer.count())
    common = count.updateMask(count.eq(cdl.size()))

    #// Mask out polygons < 20000 sqm.
    vec = common.reduceToVectors(scale=scale, geometry=geom, eightConnected=False, maxPixels=295000000, bestEffort = True)
    vec = ee.FeatureCollection(vec)

    f = lambda image: image.set('area', image.area(1))
    vec = vec.map(f)
    vec = vec.filter(ee.Filter.gt('area', 20000)) #// normal: 20000, fresno: 800000 because too big
    return vec.union(1)


def get_crop_mask_for_geom(geom, crop_id=69, historic_years=4):
    """Given a geometry, return the coverage mask for requested crop.
    Args:
        geom: A geometry
        crop_id: attribute identifier for crop type. Default: 69
    Returns:
        ee.Image useable as a mask to obtain data specific to crop growth area.
    """
    cdl_collection = ee.ImageCollection(CDL_COLLECTION_PATH)
    f = lambda image: image.select('cropland').clip(geom).updateMask(image.select('cropland').eq(crop_id))
    clipped_cdl_collection = cdl_collection.map(f)
    image_with_overlaps = clipped_cdl_collection.limit(historic_years, 'system:index', False).reduce(ee.Reducer.count())
    return image_with_overlaps.updateMask(image_with_overlaps.eq(historic_years))
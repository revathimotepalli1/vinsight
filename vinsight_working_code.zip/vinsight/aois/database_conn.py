import os
from google.cloud.sql.connector import Connector, IPTypes

# Set environment variables explicitly
os.environ['INSTANCE_CONNECTION_NAME'] = 'bountiful-aws-transfer:us-west1:bountiful-test-final-db'
os.environ['DB_USER'] = 'vinsight'
os.environ['DB_PASS'] = 'Mbount22!3'
os.environ['DB_NAME'] = 'vinsightprod'

def verify_database_connection():
    connector = Connector()
    conn = None
    connection_name = os.environ.get("INSTANCE_CONNECTION_NAME")
    user = os.environ.get("DB_USER")
    password = os.environ.get("DB_PASS")
    db = os.environ.get("DB_NAME")
    ip_type = IPTypes.PRIVATE if os.environ.get("PRIVATE_IP") == 'true' else IPTypes.PUBLIC

    try:
        # Establishing the connection
        conn = connector.connect(
            connection_name,
            "pg8000",
            user=user,
            password=password,
            db=db,
            ip_type=ip_type,
        )
        print("Database connection established successfully.")
    except Exception as e:
        print(f"Failed to establish database connection: {e}")
    finally:
        if conn:
            conn.close()
            print("Database connection closed.")

if __name__ == "__main__":
    verify_database_connection()
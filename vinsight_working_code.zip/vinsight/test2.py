from google.cloud import storage


def list_latest_folders_with_subfolder(bucket_name, model, subfolder_name, sub_subfolder_name,num_latest=1):
    """List the latest folders containing a specific subfolder inside a given model's executions path in GCS.

    Args:
        bucket_name (str): Name of the GCS bucket.
        model (str): The model name (e.g., 'geospatial').
        subfolder_name (str): The subfolder name to search for (e.g., '76').
        num_latest (int): Number of latest folders to return.

    Returns:
        list: List of the latest folder names containing the specific subfolder, sorted in descending order.
    """
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    base_path = f"{model}/executions/"
    
    # Fetch blobs under the base path
    blobs = bucket.list_blobs(prefix=base_path)

    # Extract unique folder names containing the subfolder
    folders = set()
    for blob in blobs:
        # Extract the folder name after the base path
        relative_path = blob.name[len(base_path):]
        parts = relative_path.split("/")
        if len(parts) > 2 and parts[1] == "results" and parts[2] == subfolder_name and parts[3] ==sub_subfolder_name:  # Check for 'results' and subfolder match
            folders.add(parts[0])

    # Sort the folders in descending order
    sorted_folders = sorted(folders, reverse=True)
    
    # Return the desired number of latest folders
    if not sorted_folders:
        print(f"No folders found under {base_path} containing subfolder '{subfolder_name}'.")
        return []
    return sorted_folders[:num_latest]

# Example usage
bucket_name = "co_vinsight_models_test"
model = "geospatial"
subfolder_name = "76"
sub_subfolder_name="1091"

latest_folders = list_latest_folders_with_subfolder(bucket_name, model, subfolder_name, sub_subfolder_name,num_latest=2)
print("Latest folders with subfolder:", latest_folders)

#!/bin/bash

# Model and Execution Configuration
MODEL="geospatial"
VERSION=$GIT_COMMIT

# Dynamically set --execution as the first argument or use a timestamp
EXECUTION="${1:-$(date "+%Y%m%d%H%M%S")}"  # Default to current timestamp if not provided

# If the first argument is '--bucket', shift the arguments
if [[ "$EXECUTION" == "--bucket" ]]; then
    shift
    EXECUTION="$(date "+%Y%m%d%H%M%S")"  # Set EXECUTION to the current timestamp if '--bucket' is provided
fi

BUCKET_PATH="${1:-co_vinsight_models_test}"  # Ensure BUCKET_PATH is the next argument
shift  # Remove the first argument (bucket) to process others

# Ensure BUCKET_PATH is provided
if [[ -z $BUCKET_PATH ]]; then
    echo "BUCKET_PATH must be set"
    exit 1
fi

# Load environment variables if the file exists
if [[ -f ~/vinsight-gen-env.env ]]; then
    export $(cat ~/vinsight-gen-env.env | sed 's/#.*//g' | xargs)
fi

# Ensure the credentials file exists
echo "Using local credentials.json"
if [[ ! -f /app/credentials.json ]]; then
    echo "ERROR: /app/credentials.json not found"
    exit 1
fi

# Copy the credentials file to the required location for Earth Engine
mkdir -p /root/geeuser/.config/earthengine
cp /app/credentials.json /root/geeuser/.config/earthengine/credentials

# Fetch metadata.json from GCS
echo "Gathering Metadata from GCS"
gsutil cp gs://$BUCKET_PATH/$MODEL/metadata.json metadata.json

# Ensure the metadata.json file is downloaded correctly
if [ ! -f metadata.json ]; then
    echo "Error: metadata.json not found, exiting."
    exit 1
fi
echo "metadata.json downloaded successfully."

# Create previous and final directories for execution
mkdir -p /tmp/previous
mkdir -p /tmp/final

mkdir -p /tmp/current/$EXECUTION/inputs
mkdir -p /tmp/final/$EXECUTION/inputs
echo "{\"version\": \"$VERSION\"}" > /tmp/current/$EXECUTION/model.json
echo "{\"version\": \"$VERSION\"}" > /tmp/final/$EXECUTION/model.json

# If no AOI file is provided, generate it
if [[ -f /overrides/aois.tsv ]]; then
    echo "Using AOI override data"
    cp /overrides/aois.tsv /tmp/current/$EXECUTION/inputs/aois.tsv
    cp /overrides/aois.tsv /tmp/final/$EXECUTION/inputs/aois.tsv
else
    echo "Retrieving AOI input data"
    python3 get-aois.py /tmp/final/$EXECUTION/inputs/aois.tsv
fi

echo "AOI file length: $(wc -l /tmp/final/$EXECUTION/inputs/aois.tsv)"
aois=$(wc -l < /tmp/final/$EXECUTION/inputs/aois.tsv)

# Run the job to generate daily weather
echo "Begin execution"
python3 historic_weather.py \
    --credentials /root/geeuser/.config/earthengine/credentials \
    --execution=$EXECUTION \
    --aois=/tmp/final/$EXECUTION/inputs/aois.tsv \
    --bucket "$BUCKET_PATH" \
    --model "$MODEL" "$@"

if [ $? -ne 0 ]; then
    echo "JobComplete: Status=failure Message='GEE job execution failure'"
    exit 1
fi

# Copy results down from GEE -> local disk (GCS -> Cloud Run)
echo "Fetching results from GCS"
mkdir -p /tmp/current/$EXECUTION/results
mkdir -p /tmp/final/$EXECUTION/results
cp /tmp/final/$EXECUTION/inputs/aois.tsv /tmp/final/$EXECUTION/results/aois.tsv

# Sync results from GCS
gsutil rsync -r gs://co_vinsight_models/$MODEL/executions/$EXECUTION /tmp/current/$EXECUTION/results
if [ $? -ne 0 ]; then
    echo "JobComplete: Status=failure Message='Failed to retrieve GEE output from GCS'"
    exit 1
fi

# Remove "ee_export" suffix from file names
find /tmp/current/$EXECUTION/* -type f | while read f; do
    mv $f ${f/ee_export/}
done

# Append files from last full execution to incremental execution to create a full dataset
python3 append.py --execution=$EXECUTION --bucket=$BUCKET_PATH --model=$MODEL && echo "Appending GEE input files"

# Sync entire storage directory to GCS
echo "Syncing final results to GCS"
gsutil rsync -r /tmp/final/$EXECUTION gs://$BUCKET_PATH/$MODEL/executions/$EXECUTION
if [ $? -ne 0 ]; then
    echo "JobComplete: Status=failure Message='Failed to copy to GCS'"
    exit 1
fi

# Upload updated metadata.json to GCS
gsutil cp metadata.json gs://$BUCKET_PATH/$MODEL/metadata.json && echo "Uploading updated Metadata to GCS"

# If we reached here, success!
echo "JobComplete: Status=success OutputPath=gs://$BUCKET_PATH/$MODEL/executions/$EXECUTION"
exit 0

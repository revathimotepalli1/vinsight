import argparse
import os
import pandas as pd
import shutil
from google.cloud import storage
from datetime import datetime

# Function to parse command-line arguments
def getopts():
    parser = argparse.ArgumentParser(description='Execute job.')
    parser.add_argument('--execution', metavar='e', type=str, help='Execution identifier to write to')
    parser.add_argument('--bucket', metavar='bp', type=str, help='Bucket path to write to')
    parser.add_argument('--model', metavar='m', type=str, help='Model to write to')
    return parser.parse_args()

opts = getopts()

# Setting up data for GCS
bucket_name = opts.bucket
MODEL = opts.model

# Setting up finding previous data
dir_path = '/tmp/current'

# Find all folders in the directory
folders = [os.path.join(dir_path, f) for f in os.listdir(dir_path) if os.path.isdir(os.path.join(dir_path, f))]
sorted_folders = sorted(folders, key=lambda x: datetime.strptime(os.path.basename(x), '%Y%m%d%H%M%S'), reverse=True)
latest_current_folder = sorted_folders[0] if sorted_folders else None
latest_datetime_run = os.path.basename(latest_current_folder) if latest_current_folder else None

# Set up GCS client
storage_client = storage.Client()

# Skip downloading file from GCS since it's already saved in tmp
# Directly read the 'aois_current_metadata.csv' from /tmp directory
csv_file_path = '/tmp/aois_current_metadata.csv'

if os.path.exists(csv_file_path):
    # Read the CSV file directly from /tmp
    df = pd.read_csv(csv_file_path, dtype={'execution': str})
    print("Contents of aois_current_metadata:")
    print(df.head())  # This will display the first few rows of the DataFrame
else:
    print(f"Error: {csv_file_path} not found!")
    exit(1)

# Check if DataFrame is empty
if df.empty:
    print("Error: The DataFrame is empty. No data loaded.")
    exit(1)

# Function to fetch previous run files from GCS
def get_gcs_files(bucket_name, model, crop_id, aoi_id, local_path):
    """Download files from the timestamp folders containing the specified crop_id and aoi_id."""
    bucket = storage_client.get_bucket(bucket_name)
    base_path = f"{model}/executions/"
    
    blobs = bucket.list_blobs(prefix=base_path)
    target_folders = {}

    print(f"Fetching files for crop_id: {crop_id}, aoi_id: {aoi_id}")
    
    # Extract folders containing the specific crop_id and aoi_id
    for blob in blobs:
        parts = blob.name[len(base_path):].split("/")
        
        if len(parts) > 4 and parts[2] == str(crop_id) and parts[3] == str(aoi_id):  # Ensure crop_id and aoi_id are strings
            timestamp_folder = parts[0]
            if timestamp_folder not in target_folders:
                target_folders[timestamp_folder] = []
            target_folders[timestamp_folder].append(blob)
            # print(f"Found folder: {timestamp_folder} containing crop_id: {crop_id}, aoi_id: {aoi_id}")
    
    # If no matching folders found, print a message and return empty
    if not target_folders:
        print(f"No matching folders found for crop_id {crop_id} and aoi_id {aoi_id}.")
        return []

    # Print all the timestamp folders that contain the specific crop_id and aoi_id
    # print(f"Timestamp folders containing crop_id {crop_id} and aoi_id {aoi_id}:")
    for timestamp_folder in target_folders:
        print(f"  - {timestamp_folder}")

    # Find the latest timestamp folder
    sorted_timestamps = sorted(target_folders.keys(), reverse=True)
    latest_timestamp = sorted_timestamps[0]
    print(f"Latest timestamp folder for crop_id {crop_id} and aoi_id {aoi_id}: {latest_timestamp}")
    path = f"{base_path}{latest_timestamp}/results/{crop_id}/{aoi_id}/"

    # Download files from the latest folder
    os.makedirs(local_path, exist_ok=True)
    for blob in target_folders[latest_timestamp]:
        local_file_path = os.path.join(local_path, os.path.basename(blob.name))
        blob.download_to_filename(local_file_path)
        print(f"Downloaded {blob.name} to {local_file_path}")
    
    return local_path

# Function to concatenate CSV files (Weather)
def concatenate_csv_weather(path_2_previous, path_2_current, output_dir, file):
    """Concatenate weather CSV files based on 'system:index'."""
    if not os.path.exists(path_2_previous):
        print(f"Previous weather file missing: {path_2_previous}")
        return
    if not os.path.exists(path_2_current):
        print(f"Current weather file missing: {path_2_current}")
        return

    df1 = pd.read_csv(path_2_previous)
    df2 = pd.read_csv(path_2_current)
    df_concat = pd.concat([df1, df2]).drop_duplicates(subset=['system:index'], keep='last')
    df_concat['system:index'] = pd.to_datetime(df_concat['system:index'], format='%Y%m%d')
    df_concat = df_concat.sort_values('system:index')
    df_concat['system:index'] = df_concat['system:index'].dt.strftime('%Y%m%d')
    os.makedirs(output_dir, exist_ok=True)
    output_file_path = os.path.join(output_dir, file)
    df_concat.to_csv(output_file_path, index=False)

# Function to concatenate CSV files (Imagery)
def concatenate_csv_imagery(path_2_previous, path_2_current, output_dir, file):
    """Concatenate imagery CSV files based on 'year'."""
    if not os.path.exists(path_2_previous):
        print(f"Previous imagery file missing: {path_2_previous}")
        return
    if not os.path.exists(path_2_current):
        print(f"Current imagery file missing: {path_2_current}")
        return

    df1 = pd.read_csv(path_2_previous)
    df2 = pd.read_csv(path_2_current)
    df_concat = pd.concat([df1, df2]).drop_duplicates(subset=['year'], keep='last')
    df_concat['year'] = pd.to_datetime(df_concat['year'], format='%Y').dt.strftime('%Y').astype(str)
    df_concat = df_concat.sort_values('year')
    df_concat = df_concat.reset_index(drop=True)
    df_concat['system:index'] = df_concat.index
    os.makedirs(output_dir, exist_ok=True)
    output_file_path = os.path.join(output_dir, file)
    df_concat.to_csv(output_file_path, index=False)

# Process each AOI from the metadata CSV
for _, row in df.iterrows():
    path = f"{MODEL}/executions/{row['execution']}/results/{row['crop_cdl_id']}/{row['aoi_crop_id']}/"
    current_path = f"{latest_current_folder}/results/{row['crop_cdl_id']}/{row['aoi_crop_id']}/"
    final_path = f"/tmp/final/{latest_datetime_run}/results/{row['crop_cdl_id']}/{row['aoi_crop_id']}/"

    if pd.isna(row['execution']) or row['execution'] == '':
        print(f"Skipping AOI {row['aoi_crop_id']} as execution is not defined.")
        shutil.copytree(current_path, final_path, dirs_exist_ok=True)
        continue

    # Download the previous data from the latest folder in GCS
    previous_path = f"/tmp/previous/{row['execution']}/results/{row['crop_cdl_id']}/{row['aoi_crop_id']}/"
    get_gcs_files(bucket_name, MODEL, str(row['crop_cdl_id']), str(row['aoi_crop_id']), previous_path)

    # Concatenate weather and imagery files
    concatenate_csv_weather(f"{previous_path}weather.csv", f"{current_path}weather.csv", final_path, 'weather.csv')
    concatenate_csv_imagery(f"{previous_path}imagery.csv", f"{current_path}imagery.csv", final_path, 'imagery.csv')

# Function to upload files to GCS
def upload_to_gcs(bucket_name, destination_blob_name, source_file_name):
    """Upload file to Google Cloud Storage."""
    bucket = storage_client.get_bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)
    if os.path.exists(source_file_name):
        blob.upload_from_filename(source_file_name)
        print(f"Uploaded {source_file_name} to {destination_blob_name}")
    else:
        print(f"File not found for upload: {source_file_name}")

# Upload results back to GCS
for _, row in df.iterrows():
    final_folder_path = f"/tmp/final/{latest_datetime_run}/results/{row['crop_cdl_id']}/{row['aoi_crop_id']}/"
    upload_to_gcs(bucket_name, f"{MODEL}/executions/{opts.execution}/results/{row['crop_cdl_id']}/{row['aoi_crop_id']}/weather.csv", f"{final_folder_path}/weather.csv")
    upload_to_gcs(bucket_name, f"{MODEL}/executions/{opts.execution}/results/{row['crop_cdl_id']}/{row['aoi_crop_id']}/imagery.csv", f"{final_folder_path}/imagery.csv")

# Upload updated metadata to GCS
upload_to_gcs(bucket_name, f"{MODEL}/metadata.json", "metadata.json")
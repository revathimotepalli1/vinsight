from google.cloud import storage

def list_latest_folders(bucket_name, model, num_latest=1):
    """List the latest folders inside a given model's executions path in GCS.

    Args:
        bucket_name (str): Name of the GCS bucket.
        model (str): The model name (e.g., 'geospatial').
        num_latest (int): Number of latest folders to return.

    Returns:
        list: List of the latest folder names, sorted in descending order.
    """
    storage_client = storage.Client()
    bucket = storage_client.get_bucket(bucket_name)
    base_path = f"{model}/executions/"
    
    # Fetch blobs under the base path
    blobs = bucket.list_blobs(prefix=base_path)

    # Extract unique folder names
    folders = set()
    for blob in blobs:
        # Extract the folder name after the base path
        parts = blob.name[len(base_path):].split("/")
        if len(parts) > 1 and parts[0].isdigit():  # Check if it's a timestamped folder
            folders.add(parts[0])

    # Sort the folders in descending order
    sorted_folders = sorted(folders, reverse=True)
    
    # Return the desired number of latest folders
    if not sorted_folders:
        print(f"No folders found under {base_path}.")
        return []
    return sorted_folders[0]

# Example usage
bucket_name = "co_vinsight_models_test"
model = "geospatial"

latest_folders = list_latest_folders(bucket_name, model, num_latest=2)
print("Latest folders:", latest_folders)




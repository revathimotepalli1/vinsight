import os  # Add this import to use environment variables
import argparse
import csv
import json
from google.cloud.sql.connector import Connector, IPTypes
from shapely.geometry import shape

# Set environment variables explicitly
os.environ['INSTANCE_CONNECTION_NAME'] = 'bountiful-aws-transfer:us-west1:bountiful-test-final-db'
os.environ['DB_USER'] = 'vinsight'
os.environ['DB_PASS'] = 'Mbount22!3'
os.environ['DB_NAME'] = 'vinsightprod'

# Query to fetch AOI data
QUERY = """
SELECT
    DISTINCT("AoiCrop".id) AS aoi_crop_id,
    "AoiCrop".crop_id AS crop_id,
    "Aoi".type AS aoi_type,
    "Aoi".coordinates AS aoi_geometry,
    "Crop".cdl_id AS crop_cdl_id
FROM "AoiCrop"
    INNER JOIN "Aoi" ON "Aoi"."id" = "AoiCrop".aoi_id
    INNER JOIN "Crop" ON "Crop"."id" = "AoiCrop".crop_id
    RIGHT JOIN "YieldHistoric" ON "YieldHistoric".aoi_crop_id = "AoiCrop".id
WHERE "AoiCrop".id IN (1091);
"""

OUTPUT_FIELDS = [
    'aoi_crop_id',
    'crop_id',
    'aoi_type',
    'aoi_geometry',
    'aoi_centroid',
    'crop_cdl_id',
    'aoi_hemisphere'
]

def _centroid(geojson):
    """Given a GeoJSON object, return its centroid as a Point."""
    s = shape(geojson)
    return {'type': 'Point', 'coordinates': list(s.centroid.coords)[0]}

def create_connection():
    """Create a database connection using environment variables."""
    connector = Connector()
    connection_name = os.environ.get("INSTANCE_CONNECTION_NAME")
    user = os.environ.get("DB_USER")
    password = os.environ.get("DB_PASS")
    db = os.environ.get("DB_NAME")
    ip_type = IPTypes.PRIVATE if os.environ.get("PRIVATE_IP") == 'true' else IPTypes.PUBLIC

    try:
        conn = connector.connect(
            connection_name,
            "pg8000",
            user=user,
            password=password,
            db=db,
            ip_type=ip_type,
        )
        print("Database connection established successfully.")
        return conn
    except Exception as e:
        print(f"Failed to establish database connection: {e}")
        raise

def get_aois(conn):
    """Fetch AOI data from the database."""
    try:
        cursor = conn.cursor()
        cursor.execute(QUERY)
        
        # Convert the result into a list of dictionaries
        columns = [desc[0] for desc in cursor.description]
        results = [dict(zip(columns, row)) for row in cursor.fetchall()]
        
        cursor.close()  # Explicitly close the cursor after use
        return results
    
    except Exception as e:
        print(f"Error fetching AOIs: {e}")
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('output_path', help="Path to save the output TSV file")
    args = parser.parse_args()

    # Connect to the database using the connection settings
    with create_connection() as conn:
        results = get_aois(conn)

        # Process the results
        for result in results:
            geojson = json.loads(result['aoi_geometry'])
            centroid = _centroid(geojson)
            result['aoi_centroid'] = json.dumps(centroid)
            result['aoi_hemisphere'] = 'N' if centroid['coordinates'][1] >= 0 else 'S'

        # for row in results[:5]:  # Print only the first 5 rows
        #     print(row)

        # Write the processed data to a TSV file
        with open(args.output_path, 'w') as tsvfile:
            writer = csv.DictWriter(
                tsvfile, fieldnames=OUTPUT_FIELDS, delimiter='\t', quotechar="'"
            )
            writer.writeheader()
            writer.writerows(results)

if __name__ == '__main__':
    main()

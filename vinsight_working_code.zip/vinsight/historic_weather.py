from __future__ import print_function
from __future__ import division
from __future__ import unicode_literals
from builtins import map
from builtins import str
from builtins import range
#from past.utils import old_div
from builtins import object
import argparse
import csv
from datetime import date, timedelta, datetime
from dateutil.parser import parse
import json
import logging
import os
import sys
import time
from socket import error as SocketException

import oauth2client
import ee
from ee.ee_exception import EEException
from datasources import cdl

import google.oauth2.credentials

import pandas as pd
import numpy as np 

CROP_TYPES = [69, 75, 76]

GC_BUCKET = 'co_vinsight_models'
MODEL_NAME = 'geospatial'
GRIDMET_COLLECTION_PATH = 'IDAHO_EPSCOR/GRIDMET'
SRTM_IMAGE_PATH = 'USGS/SRTMGL1_003'
GSSURGO_NICCDC_IMAGE_PATH = 'users/michaelbertino/gssurgo_niccdc_10m_cali'
GSSURGO_ICCDC_IMAGE_PATH = 'users/michaelbertino/gssurgo_iccdc_10m_cali'
LANDSAT_8 = 'LANDSAT/LC08/C02/T1_TOA'
LANDSAT_7 = 'LANDSAT/LE07/C02/T1_TOA'
LANDSAT_7_2 = 'LANDSAT/LE07/C02/T1_RT_TOA'
LANDSAT_5 = 'LANDSAT/LT05/C02/T1_TOA'
SENTINEL_2 = 'COPERNICUS/S2'

log = logging.getLogger()

class VinsightTask(object):
    """GEE Task wrapper to manage attempt counts & restart."""
    _fn = None
    _kwargs = None
    ee_task = None
    attempt = 0

    def __init__(self, collection, collection_name, gc_bucket,
                 model_name, execution, crop_type, feature_id, gdrive=False):
        """ export a ee.FeatureCollection to google drive or cloud storage
          Args:
            collection: ee.FeatureCollection containing metrics to export
            collection_name: collection metrics group name
            gc_bucket: google cloud bucket
            model_name: Model that is being executed
            gdrive: export to google drive if True
            execution: execution name
            crop_type: crop type
            feature_id: feature id
          Returns:
            ee batch task
        """
        description = '%s:%s:%s:%s' % (execution, feature_id, crop_type, collection_name)
        prefix = '%s/executions/%s/%s/%s/%s' % (model_name, execution, crop_type,
          feature_id, collection_name)
        if gdrive:
            self._fn = ee.batch.Export.table.toDrive
            self._kwargs = dict(
                collection=collection,
                description=description,
                folder=gc_bucket,
                fileNamePrefix=prefix.replace('/', '_'))
        else:
            self._fn = ee.batch.Export.table.toCloudStorage
            self._kwargs = dict(
                collection=collection,
                description=description,
                bucket=gc_bucket,
                fileNamePrefix=prefix)

    def start(self):
        try:
            self.ee_task = self._fn(**self._kwargs)
            self.ee_task.start()
        except (EEException, SocketException, TypeError) as error:
            print(("error while starting ee task - line 76", error))
            ee_initialize()
        self.attempt += 1
        folder = self._kwargs.get('folder', self._kwargs.get('bucket'))
        log.info(
            'task=%s, path=%s/%s.csv, attempt=%s' % (self.ee_task.id, folder,
                                                     self._kwargs['fileNamePrefix'],
                                                     self.attempt))

def _get_acreage(region):
    """Get geometry acreage.

    Forces to 32611 to account for inputs of unknown original projection
    (GEE gives us weird results in this case).
    """
    return region.geometry().area(0.001,'EPSG:32611').multiply(0.000247105).getInfo()

def get_physical_collection_for_feature(images, feature):
    """Given a geometry, get aggregate metrics.

    Args:
      feature: feature for which to aggregate metrics.
      images: object containing elevation and soil ee.Image's
    Returns:
      ee.FeatureCollection, ex:
      [
        {geometry: [..], properties: {system:index: 0, elevation: 52.3, ..}}
        ...
      ]
    """

    srtm_image = images['srtm_image']
    iccdc_image = images['iccdc_image']
    niccdc_image = images['niccdc_image']

    srtm_mean_values = srtm_image.reduceRegion(ee.Reducer.mean(), feature)

    # renaming bands to avoid names conflict
    iccdc_image = iccdc_image.select(['b1'], ['iccdc'])
    niccdc_image = niccdc_image.select(['b1'], ['niccdc'])

    # merge iccdc_image and niccdc_image bands in a new image
    niccdc_iccdc_image = ee.Image([niccdc_image, iccdc_image])

    soil_mode_values = niccdc_iccdc_image.reduceRegion(
      reducer = ee.Reducer.mode(),
      geometry = feature.geometry(),
      scale = 300,
      bestEffort = True)

    physical_values = {
      'elevation': srtm_mean_values.get('elevation'),
      'iccdc': soil_mode_values.get('iccdc'),
      'niccdc': soil_mode_values.get('niccdc')
    }

    feature = ee.Feature(feature.geometry().centroid(), physical_values)
    physical_data_collection = ee.FeatureCollection([feature])
    return physical_data_collection

def get_weather_collection_for_feature(collection, feature):
    """Given a collection of weather data and a geometry, get aggregate metrics.

    Args:
        collection: multi-band ImageCollection with weather data.
        feature: feature for which to aggregate metrics.
    Returns:
        ee.FeatureCollection in which each feature represents the summarised
        metrics for a single day. ex:
        [
            {geometry: [..], properties: {system:index: 20150125, tmmn_f: 52.3, ..}},
            {geometry: [..], properties: {system:index: 20150126, tmmn_f: 51.7, ..}},
            ...
        ]
    """

    def _get_scale(feature):
        acres = _get_acreage(feature)
        return 100 if acres < 100 else 2000

    scale = _get_scale(feature)

    def _process_image(image):
        """Given a multi-band Image, return summarized metrics for feature.

        Note: `feature` in this case returns to the feature passed to the parent
        function. This function generates metrics for a single Image in the overall
        historic collection (i.e.: a single day).

        Returns:
            ee.Feature
        """
        geom = feature.geometry()
        meanBands = image.select(['tmmn', 'tmmx', 'rmax', 'rmin', 'vs', 'pr', 'eto', 'srad'],
                                 ['tmmn', 'tmmx', 'rmax', 'rmin', 'vs', 'pr', 'eto', 'srad'])
        meanResults = meanBands.reduceRegion(ee.Reducer.mean(), scale=scale, geometry=geom)
        
        return ee.Feature(geom.centroid(), {
          'tmmn': ee.Algorithms.If(meanResults.get('tmmn'),ee.Number(meanResults.get('tmmn')).multiply(9).divide(5).subtract(459.67), None),
          'tmmx': ee.Algorithms.If(meanResults.get('tmmx'),ee.Number(meanResults.get('tmmx')).multiply(9).divide(5).subtract(459.67), None),
          'rmax': ee.Algorithms.If(meanResults.get('rmax'), ee.Number(meanResults.get('rmax')), None),
          'rmin': ee.Algorithms.If(meanResults.get('rmin'), ee.Number(meanResults.get('rmin')), None),
          'vs': ee.Algorithms.If(meanResults.get('vs'), ee.Number(meanResults.get('vs')), None),
          'pr':  ee.Algorithms.If(meanResults.get('pr'), ee.Number(meanResults.get('pr')).divide(25.4), 0),
          # returns eto value, or null if unavailable
          'eto': ee.Algorithms.If(meanResults.get('eto'),
                                  ee.Number(meanResults.get('eto')).divide(25.4),
                                  None),
          'srad': ee.Algorithms.If(meanResults.get('srad'), ee.Number(meanResults.get('srad')), None)
        })
    return collection.map(_process_image)
    
def get_gridmet_meta(*arg):
    """Gets the last permanent date for gridmet data.
    Args:
        none
    Returns:
        date string
    """
    sd= str(date.today() - timedelta(190))
    ed = str(date.today())
    
    grmeta = ee.ImageCollection(GRIDMET_COLLECTION_PATH).filterDate(sd, ed)
    
    values = grmeta.reduceColumns(ee.Reducer.toList(2), ['system:index','status']).values().get(0)
    list_values = ee.List(values)
    dic_values = ee.Dictionary(list_values.flatten())
    d=dic_values.getInfo()
    
    df=pd.DataFrame(d.items(), columns=['Date', 'Status'])
    status_perm= df.query('Status == "permanent"').tail(1).iloc[0]['Date']
    gridmet_date=str(datetime.strptime(status_perm, '%Y%m%d'))
    
    return gridmet_date

def get_landsat_collection_for_feature(collections, feature, feature_mask, start_date, end_date):
    """Given a collection of landsat images and a geometry, get aggregate metrics.

    Args:
      collection: object containing landsat images (ee.Images)
      feature: feature for which to aggregate metrics.
      start_date, end_date: make up the year range from which we base the aggregation
    Returns:
      ee.FeatureCollection, ex:
      [
        {geometry: [..], properties: {*}}
        ...
      ]
    """
    d = date.today()
    start_year = parse(start_date).year
    end_year = parse(end_date).year

    if d.month >= 10:
        year_range = list(range(start_year, end_year+2))
    else:
        year_range = list(range(start_year, end_year+1))

    feature = ee.FeatureCollection(feature).geometry()

    months = [10, 11, 12, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    monthnames = ['placeholder', '04_Jan', '05_Feb', '06_Mar', '07_Apr', '08_May',
                  '09_Jun', '10_Jul', '11_Aug', '12_Sep', '01_Oct', '02_Nov', '03_Dec']

    LS8 = collections['LS8']
    LS7 = collections['LS7']
    LS72 = collections['LS72']
    LS5 = collections['LS5']

    LS8_ = LS8.map(ee.Algorithms.Landsat.simpleCloudScore)\
    .select(['B[2-7].*', 'cloud'])

    LS7_ = LS7.map(ee.Algorithms.Landsat.simpleCloudScore)\
      .select(['B1', 'B2', 'B3', 'B4', 'B5', 'B7', 'cloud'],
              ['B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'cloud']) #rename bands to match Landsat 8 due to different band order

    LS7_2 = LS72.map(ee.Algorithms.Landsat.simpleCloudScore)\
      .select(['B1', 'B2', 'B3', 'B4', 'B5', 'B7', 'cloud'],
              ['B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'cloud']) #rename bands to match Landsat 8 due to different band order

    LS5_ = LS5.map(ee.Algorithms.Landsat.simpleCloudScore)\
      .select(['B1', 'B2', 'B3', 'B4', 'B5', 'B7', 'cloud'],
            ['B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'cloud']) #rename bands to match Landsat 8 due to different band order


    # Performing check on LS7 source to see if images exist for the month. If its not the first day of the month and there are values tied to 'features' carry on, else, substitute LS7 for LS72
    if str('%02d' % d.day) != '01':
        check = LS7_.filterBounds(feature.bounds())\
                  .filterDate(str(d.year)+'-'+str(d.month)+'-01', str(d.year)+'-'+str(d.month)+'-'+str('%02d' % d.day))
        if check.getInfo()['features']:
            collection = ee.ImageCollection((LS8_).merge(LS7_).merge(LS5_))
        else:
            collection = ee.ImageCollection((LS8_).merge(LS7_2).merge(LS5_)) 
    else:
        collection = ee.ImageCollection((LS8_).merge(LS7_2).merge(LS5_))

    # Convert ee.imageCollection to multi-Band single image.
    def my_multiband (collection):
      def concat(a, b):
        return ee.Image(b).addBands(a)
      multiband = ee.Image(collection.slice(1).iterate(concat, collection.get(0)))
      return multiband

    def process_year(year):
        """Given a year, returns metrics for every month the year.

        Args:
          year: for which we calculate the aggregation
        Returns:
          ee.FeatureCollection
        """
        def process_month(month):
            """Given a month, returns metrics for that month.

            Note:
              `year` referes to the parent's year
              `feature` referes to the root function's feature (get_landsat_collection_for_feature)
              `collection` referes to root function's collection(get_landsat_collection_for_feature)
              `monthnames` referes to root function's monthnames(get_landsat_collection_for_feature)
              `months` referes to root function's months(get_landsat_collection_for_feature)
            Args:
              month: for which we calculate the aggregation
            Returns:
              ee.Image
            """

            bound_collection = collection.filterBounds(feature.bounds())\
                                         .filterDate(str(year-1)+'-10-01', str(year)+'-10-01')\
                                         .filter(ee.Filter.calendarRange(ee.Number(month), ee.Number(month), 'month'))


            def normalizedBands(image):
                return image.addBands(image.normalizedDifference(['B5', 'B4']).rename(names=['ndviLS']))

            combined = ee.ImageCollection(bound_collection).map(normalizedBands)

            def apply_cloud_mask(col):
              # Determine the per-pixel cloud score threshold from minimal cloudscore + 20 cloudscore:
              cloudThreshold = col.reduce(ee.Reducer.min())\
                                          .select('cloud_min')\
                                          .add(20)

              # Mask out pixels above the cloud score threshold, and update the mask of
              # the remaining pixels to be no higher than the cloud score mask.
              def updateMask(image):
                image = ee.Image(image)
                cloud = image.select('cloud')
                cloudMask = cloud.mask().min(cloud.lte(cloudThreshold))
                return image.mask(image.mask().min(cloudMask))

              return col.map(updateMask)

            # handling no cloud band
            masked = ee.Algorithms.If(
              combined.get('cloud'),
              apply_cloud_mask(combined),
              combined)

            # Drop the cloud band and QA bands.
            masked = ee.ImageCollection(masked).select('B[2-7].*', 'ndviLS')

          	# Take the (mask-weighted) median of the good pixels.
            result = masked.reduce(ee.Reducer.median())\
                                      .set('month', month)

            # Force the mask up to 1 if it's non-zero, to hide L7 SLC artifacts
            # handling no values/bands
            result = ee.Algorithms.If(
              result.bandNames(),
              result.mask(result.mask().gt(0)),
              result)

            result = ee.Image(result)

            badNames = result.bandNames()

            def construct_month_band_name(x):
          	    return ee.String(x).replace('_[^_]*$', '').cat('_')\
                  .cat(ee.String(ee.List(monthnames).get(month)))

            # Establish cleaned up band names by removing the suffix that reduce() added:
            goodNames = badNames.map(construct_month_band_name)
          	# Clean up band names
            result = result.select(badNames, goodNames)
            return result

        year_result = ee.ImageCollection(list(map(process_month, months))).toList(1000)

        # Convert to multi-Band single image
        image = ee.Image(my_multiband(year_result))
        image = image.updateMask(feature_mask)
        data = image.reduceRegion(
          geometry=feature,
          reducer=ee.Reducer.mean(),
          scale=30,
          tileScale=4,
          bestEffort=True)
        data = data.set('year', str(year))
        return ee.Feature(None, data)

    result = list(map(process_year, year_range))
    return ee.FeatureCollection(result)
    
def get_sentinel_collection_for_feature(sentinel_collection, feature, feature_mask, start_date, end_date):
    """Given a collection of landsat images and a geometry, get aggregate metrics.
    Args:
      collection: object containing landsat images (ee.Images)
      feature: feature for which to aggregate metrics.
      start_date, end_date: make up the year range from which we base the aggregation
    Returns:
      ee.FeatureCollection, ex:
      [
        {geometry: [..], properties: {*}}
        ...
      ]
    """
    d = date.today()
    start_year = parse(start_date).year
    end_year = parse(end_date).year

    if d.month >= 10:
        year_range = list(range(start_year, end_year+2))
    else:
        year_range = list(range(start_year, end_year+1))

    feature = ee.FeatureCollection(feature).geometry()

    months = [10, 11, 12, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    monthnames = ['placeholder', '04_Jan', '05_Feb', '06_Mar', '07_Apr', '08_May',
                  '09_Jun', '10_Jul', '11_Aug', '12_Sep', '01_Oct', '02_Nov', '03_Dec']



    #Sentinel_ = sentinel_collections.select(['B1', 'B2', 'B3', 'B4','B5','B6','B7','B8','B8A', 'B9', 'B11', 'B12','MSK_CLDPRB', 'QA60'])
    #check = sentinel_collections.filterBounds(feature.bounds())\
              #.filterDate(str(d.year)+'-'+str(d.month)+'-01', str(d.year)+'-'+str(d.month)+'-'+str('%02d' % d.day))

    collection = sentinel_collection

    # Convert ee.imageCollection to multi-Band single image.
    def my_multiband (collection):
      def concat(a, b):
        return ee.Image(b).addBands(a)
      multiband = ee.Image(collection.slice(1).iterate(concat, collection.get(0)))
      # print('multiband-----: ', multiband)
      return multiband

    def process_year(year):
        """Given a year, returns metrics for every month the year.
        Args:
          year: for which we calculate the aggregation
        Returns:
          ee.FeatureCollection
        """
        def process_month(month):
            """Given a month, returns metrics for that month.
            Note:
              `year` referes to the parent's year
              `feature` referes to the root function's feature (get_landsat_collection_for_feature)
              `collection` referes to root function's collection(get_landsat_collection_for_feature)
              `monthnames` referes to root function's monthnames(get_landsat_collection_for_feature)
              `months` referes to root function's months(get_landsat_collection_for_feature)
            Args:
              month: for which we calculate the aggregation
            Returns:
              ee.Image
            """
            
            # Placeholder for sentinel bands before 2017 (before data was available)
            if year < 2016: 
                bound_collection = collection.set('B1', 0)
            else:
                bound_collection = collection.filterBounds(feature.bounds())\
                                            .filterDate(str(year-1)+'-10-01', str(year)+'-10-01')\
                                            .filter(ee.Filter.calendarRange(ee.Number(month), ee.Number(month), 'month'))

            def normalizedBands(image):
                return image.addBands(image.normalizedDifference(['B8', 'B4']).rename(names=['ndviS']))
                
            
            def renameBands(image):
                bands = ['B1','B2','B3','B4','B5','B6','B7','B8','B9','B11','B12','ndviS']
                new_bands = ['B1S','B2S','B3S','B4S','B5S','B6S','B7S','B8S','B9S','B11S','B12S','ndviS']
                 
                return image.select(bands).rename(names = new_bands)
            

            combined = ee.ImageCollection(bound_collection).map(normalizedBands).map(renameBands)
            

            def apply_cloud_mask(col):
              # Determine the per-pixel cloud score threshold from minimal cloudscore + 20 cloudscore:
              cloudThreshold = col.reduce(ee.Reducer.min())\
                                          .select('cloud_min')\
                                          .add(20)

              # Mask out pixels above the cloud score threshold, and update the mask of
              # the remaining pixels to be no higher than the cloud score mask.
              def updateMask(image):
                image = ee.Image(image)
                cloud = image.select('cloud')
                cloudMask = cloud.mask().min(cloud.lte(cloudThreshold))
                return image.mask(image.mask().min(cloudMask))

              return col.map(updateMask)

            # handling no cloud band
            masked = ee.Algorithms.If(
              combined.get('cloud'),
              apply_cloud_mask(combined),
              combined)

            # Drop the cloud band and QA bands.
            masked = ee.ImageCollection(combined).select(['B1S','B2S','B3S','B4S','B5S','B6S','B7S','B8S','B9S','B11S','B12S','ndviS'])
                        
          	# Take the (mask-weighted) median of the good pixels.
            result = masked.reduce(ee.Reducer.median())\
                                      .set('month', month)

            # Force the mask up to 1 if it's non-zero, to hide L7 SLC artifacts
            # handling no values/bands
            result = ee.Algorithms.If(
              result.bandNames(),
              result.mask(result.mask().gt(0)),
              result)
             
                
            result = ee.Image(result)
                        
            badNames = result.bandNames()
            
            
            def construct_month_band_name(x):
                return ee.String(x).replace('_[^_]*$', '').cat('_')\
                  .cat(ee.String(ee.List(monthnames).get(month)))

            # def construct_month_band_name(x):
            #   return  ee.String(x).cat(ee.String(ee.List(monthnames).get(month)))
             
            # Establish cleaned up band names by removing the suffix that reduce() added:
            goodNames = badNames.map(construct_month_band_name)

          	# Clean up band names
            result = result.select(badNames, goodNames)
            return result

        year_result = ee.ImageCollection(list(map(process_month, months))).toList(1000)

        # Convert to multi-Band single image
        image = ee.Image(my_multiband(year_result))
        # image = image.updateMask(feature_mask)
        data = image.reduceRegion(
          geometry=feature,
          reducer=ee.Reducer.mean(),
          scale=10,
          tileScale=8,
          bestEffort=True)
        data = data.set('year', str(year))

        # Make placeholder bands null for sentinel before 2017
        if year < 2016:
            
            bandlist = ['B1S_01_Oct', 'B2S_01_Oct', 'B3S_01_Oct', 'B4S_01_Oct', 'B5S_01_Oct', 'B6S_01_Oct', 'B7S_01_Oct', 'B8S_01_Oct', 'B9S_01_Oct', 'B11S_01_Oct', 'B12S_01_Oct', 'ndviS_01_Oct', 'B1S_02_Nov', 'B2S_02_Nov', 'B3S_02_Nov', 'B4S_02_Nov', 'B5S_02_Nov', 'B6S_02_Nov', 'B7S_02_Nov', 'B8S_02_Nov', 'B9S_02_Nov', 'B11S_02_Nov', 'B12S_02_Nov', 'ndviS_02_Nov', 'B1S_03_Dec', 'B2S_03_Dec', 'B3S_03_Dec', 'B4S_03_Dec', 'B5S_03_Dec', 'B6S_03_Dec', 'B7S_03_Dec', 'B8S_03_Dec', 'B9S_03_Dec', 'B11S_03_Dec', 'B12S_03_Dec', 'ndviS_03_Dec', 'B1S_04_Jan', 'B2S_04_Jan', 'B3S_04_Jan', 'B4S_04_Jan', 'B5S_04_Jan', 'B6S_04_Jan', 'B7S_04_Jan', 'B8S_04_Jan', 'B9S_04_Jan', 'B11S_04_Jan', 'B12S_04_Jan', 'ndviS_04_Jan', 'B1S_05_Feb', 'B2S_05_Feb', 'B3S_05_Feb', 'B4S_05_Feb', 'B5S_05_Feb', 'B6S_05_Feb', 'B7S_05_Feb', 'B8S_05_Feb', 'B9S_05_Feb', 'B11S_05_Feb', 'B12S_05_Feb', 'ndviS_05_Feb', 'B1S_06_Mar', 'B2S_06_Mar', 'B3S_06_Mar', 'B4S_06_Mar', 'B5S_06_Mar', 'B6S_06_Mar', 'B7S_06_Mar', 'B8S_06_Mar', 'B9S_06_Mar', 'B11S_06_Mar', 'B12S_06_Mar', 'ndviS_06_Mar', 'B1S_07_Apr', 'B2S_07_Apr', 'B3S_07_Apr', 'B4S_07_Apr', 'B5S_07_Apr', 'B6S_07_Apr', 'B7S_07_Apr', 'B8S_07_Apr', 'B9S_07_Apr', 'B11S_07_Apr', 'B12S_07_Apr', 'ndviS_07_Apr', 'B1S_08_May', 'B2S_08_May', 'B3S_08_May', 'B4S_08_May', 'B5S_08_May', 'B6S_08_May', 'B7S_08_May', 'B8S_08_May', 'B9S_08_May', 'B11S_08_May', 'B12S_08_May', 'ndviS_08_May', 'B1S_09_Jun', 'B2S_09_Jun', 'B3S_09_Jun', 'B4S_09_Jun', 'B5S_09_Jun', 'B6S_09_Jun', 'B7S_09_Jun', 'B8S_09_Jun', 'B9S_09_Jun', 'B11S_09_Jun', 'B12S_09_Jun', 'ndviS_09_Jun', 'B1S_10_Jul', 'B2S_10_Jul', 'B3S_10_Jul', 'B4S_10_Jul', 'B5S_10_Jul', 'B6S_10_Jul', 'B7S_10_Jul', 'B8S_10_Jul', 'B9S_10_Jul', 'B11S_10_Jul', 'B12S_10_Jul', 'ndviS_10_Jul', 'B1S_11_Aug', 'B2S_11_Aug', 'B3S_11_Aug', 'B4S_11_Aug', 'B5S_11_Aug', 'B6S_11_Aug', 'B7S_11_Aug', 'B8S_11_Aug', 'B9S_11_Aug', 'B11S_11_Aug', 'B12S_11_Aug', 'ndviS_11_Aug', 'B1S_12_Sep', 'B2S_12_Sep', 'B3S_12_Sep', 'B4S_12_Sep', 'B5S_12_Sep', 'B6S_12_Sep', 'B7S_12_Sep', 'B8S_12_Sep', 'B9S_12_Sep', 'B11S_12_Sep', 'B12S_12_Sep', 'ndviS_12_Sep']
            
            for x in bandlist:
                data = data.set(x, '')
    
            
        return ee.Feature(None, data)

    result = list(map(process_year, year_range))
    return ee.FeatureCollection(result)

def monitor(tasks, restart_attempts=3):
    # very basic monitoring
    incomplete = True
    successive_fails = 0
    while incomplete:
        try:

          for task in tasks:
              # if status is failed, resubmit the task up to restart_attempts times
              status = task.ee_task.status()
              #if status['state'] == 'FAILED' and task.attempt < restart_attempts:
              if status['state'] == 'FAILED': # and task.attempt < restart_attempts:
                  tasks.remove(task)
                  #log.error('task=%s, attempt=%s failed' % (status['id'], task.attempt))
                  #task.start()
          # monitor
          statuses = [task.ee_task.status()['state'] for task in tasks]
          pending = [s in ['UNSUBMITTED', 'READY', 'RUNNING'] for s in statuses]
          log.info('%s/%s jobs pending' % (sum(pending), len(statuses),))
          if any(pending):
            time.sleep(60)
          else:
            incomplete = False
            for task in tasks:
              status = task.ee_task.status()
              print('\t'.join([
                status['id'],
                status['state'],
                '%s/%s' % (task.ee_task.config.get('outputBucket', task.ee_task.config.get('driveFolder')),
                           task.ee_task.config.get('outputPrefix', task.ee_task.config.get('driveFileNamePrefix')),)]))
          successive_fails = 0
        except (EEException, SocketException, TypeError) as error:
          print(("failure again- line 362", error))
          #if successive_fails == 3:
          #  raise
          # re-initialize connection
          ee.Initialize()
          successive_fails += 1
          time.sleep(60)

def ee_initialize():
  opts = getopts()
  credentials_file = opts.credentials
  tokens = json.load(open(credentials_file))
  refresh_token = tokens['refresh_token']
  credentials = google.oauth2.credentials.Credentials(None, client_id = ee.oauth.CLIENT_ID,client_secret = ee.oauth.CLIENT_SECRET, id_token =  None, refresh_token = refresh_token, token_uri = 'https://accounts.google.com/o/oauth2/token', scopes = None)
  #credentials = oauth2client.client.OAuth2Credentials(None, ee.oauth.CLIENT_ID, ee.oauth.CLIENT_SECRET, refresh_token, None,'https://accounts.google.com/o/oauth2/token', None)
  try:
    ee.Initialize(credentials, opt_url='https://earthengine-highvolume.googleapis.com', project = 'vinsight-modeling')
  except (EEException, SocketException, TypeError) as error:
    print(("error caught while ee init - line 489", error))
    time.sleep(60)
    ee.Initialize(credentials, opt_url='https://earthengine-highvolume.googleapis.com', project = 'vinsight-modeling')

  sys.exit(main())


def getopts():
    parser = argparse.ArgumentParser(description='Execute job.')
    parser.add_argument('--aois', metavar='a', type=str,
                        help='Location of AOI input tsv file')
    parser.add_argument('--execution', metavar='e', type=str,
                        help='Execution identifier to write to')
    parser.add_argument('--outputs', type=str,
                        help='CSV list of outputs to be generated: weather | weather,imagery | imagery,physical')
    parser.add_argument('--gdrive', action='store_true',
                        help='Write to Google Drive, not GCS.')
    parser.add_argument('--verbose', action='store_true',
                        help='Log at DEBUG level')
    parser.add_argument('--credentials', type=str,
                        help='File Path where credentials are stored')
    parser.add_argument('--start', type=int,
                            help='start')
    parser.add_argument('--total', type=int,
                            help='total')
    parser.add_argument('--bucket', required=False, help="GCS Bucket path")
    parser.add_argument('--model', required=False, help="Model name")
    return parser.parse_args()
    
def dates_to_run(aois, metadata):
    """Given the current list of aoi crop ids and existing metadata, returns start dates for weather and imagery runs.
    Args:
      aois: from aois.tsv from get-aois.py script (aoi-crop-ids)
      metadata: from metadata.json at the top level folder of last run dates
    Returns:
      DataFrame of start dates based on aoi crop ids
    """
    df = pd.read_csv(aois, sep='\t')
    df['aoi_crop_id'] = df['aoi_crop_id'].astype(str)
    cr_aoi = set(df['aoi_crop_id'])
    list_meta = list(metadata.keys())
    x = pd.DataFrame()

    # iterate over the run dates to see when AOI was last run
    for item in list_meta:
        a = metadata[item].get('aoi')
        aoi = set(a) & cr_aoi
        if aoi:
            lrd = metadata[item].get('lastrundate')
            lpwd = metadata[item].get('lastpermweather')
            execution = item
            x = pd.concat([x, pd.DataFrame({
                'aoi': list(aoi),
                'lrd': [lrd]*len(aoi),
                'lpwd': [lpwd]*len(aoi),
                'execution': [execution]*len(aoi)
            })])
    # run from 2000 if empty
    if x.empty:
        fin = pd.DataFrame({
            'aoi_crop_id': None,
            'start_date_ls': pd.to_datetime('20000101', format='%Y%m%d', errors='ignore'),
            'start_date_sent': pd.to_datetime('20161001', format='%Y%m%d', errors='ignore'),
            'start_date_w': pd.to_datetime('20000101', format='%Y%m%d', errors='ignore'),
            'execution': None
        }, index=[0])
    else:
        x[['lrd', 'lpwd']] = x[['lrd', 'lpwd']].apply(pd.to_datetime, format='%Y-%m-%d %H:%M:%S', errors='coerce')
        x['start_date_sent'] = pd.to_datetime('20161001', format='%Y%m%d', errors='ignore')
        fin = x.sort_values(['lrd', 'lpwd', 'execution'], ascending=[False, False, False]) \
               .drop_duplicates(['aoi']) \
               .rename({'aoi': 'aoi_crop_id', 'lrd': 'start_date_ls', 'lpwd': 'start_date_w'}, axis=1) \
               [['aoi_crop_id', 'start_date_ls', 'start_date_sent', 'start_date_w', 'execution']]
        
    # check for new AOI CROP IDs
    # aois from metadata.json
    a = set(fin['aoi_crop_id'])
    # cr_aois are aois from aois.tsv

    aoi2 = list(a.symmetric_difference(cr_aoi))
    # Handling corner case where none of the aois in aois.tsv are in the metadata file. 
    aoi2 = [x for x in aoi2 if x is not None]
    
    y2 = pd.DataFrame({
        'aoi_crop_id': aoi2,
        'start_date_ls': pd.to_datetime('20000101', format='%Y%m%d', errors='ignore'),
        'start_date_sent': pd.to_datetime('20161001', format='%Y%m%d', errors='ignore'),
        'start_date_w': pd.to_datetime('20000101', format='%Y%m%d', errors='ignore'),
        'execution': np.nan
    })

    final = pd.concat([fin, y2], ignore_index=True).sort_values('aoi_crop_id').merge(df, on='aoi_crop_id', how='left').dropna(subset=['aoi_crop_id'])
    final['aoi_crop_id'] = final['aoi_crop_id'].astype(str)
    final['crop_cdl_id'] = final['crop_cdl_id'].astype(float).astype(int).astype(str)
    final['execution'] = final['execution'].apply(lambda x: str(x) if pd.notna(x) and x != 'N/A' else x)
    #final['execution'] = final['execution'].astype(str)
    
    return final

 

def main():
    """Generate historic daily weather data, per geometry.

    Result files are stored in Google Cloud Storage or Google Drive.
    """
    opts = getopts()
    logging.basicConfig(format='%(asctime)s %(levelname)s -- %(message)s')
    log.setLevel(logging.DEBUG if opts.verbose else logging.INFO)
    tasks = []
    
    #start_date = '2016-01-01'
    #start_date_sent = '2016-10-01'
    
    end_date = str(date.today())
    log.info('starting job. model=%s execution=%s' % (os.getenv('GIT_COMMIT', None), opts.execution,))

    #gridmet_collection = ee.ImageCollection(GRIDMET_COLLECTION_PATH)\
      #.filterDate(start_date, end_date)
    srtm_image = ee.Image(SRTM_IMAGE_PATH)
    iccdc_image = ee.Image(GSSURGO_ICCDC_IMAGE_PATH)
    niccdc_image = ee.Image(GSSURGO_NICCDC_IMAGE_PATH)

    physical_images = {
      'srtm_image': srtm_image,
      'iccdc_image': iccdc_image,
      'niccdc_image': niccdc_image
    }

    landsat_collections = {
          'LS8': ee.ImageCollection(LANDSAT_8),
          'LS7': ee.ImageCollection(LANDSAT_7),
          'LS72': ee.ImageCollection(LANDSAT_7_2),
          'LS5': ee.ImageCollection(LANDSAT_5)
    }
    
    sentinel_collection = ee.ImageCollection(SENTINEL_2)

    outputs = opts.outputs.split(',') if opts.outputs else ['weather', 'physical', 'imagery'] 
    
    # calling metadata
    with open('metadata.json') as f:
        data_existing = json.load(f)
    data_new = {}
    ll = []
    lrd = opts.execution
    lrd_new = str(date.today())
    lpwd = get_gridmet_meta()

    def _get_best_cdl_for_geom(region, _crop_type, scale, historic_years=3):
        """Utility to find best CDL config from historic yearsself.

        Evaluates CDL responses and incrementally reduces number of historic years
        retrieved (toward most recent year) in order to yield representative
        layer. Returns once any results are found.
        """
        min_acreage = 50
        region_cdl = cdl.get_crop_vectors_for_geom(
            region, _crop_type, scale=scale, historic_years=historic_years)
        area = _get_acreage(region_cdl)
        log.debug('attempting fetch for historic_years=%s, acres=%s' % (historic_years, area))
        if area >= min_acreage:
            return (
                region_cdl,
                cdl.get_crop_mask_for_geom(region, _crop_type, historic_years=historic_years),
                area)
        else:
            if historic_years == 1:
                return (None, None, 0,)
            else:
                return _get_best_cdl_for_geom(
                    region, _crop_type, scale=scale, historic_years=historic_years-1)
            
    #with open(opts.aois, 'r') as f:
        #aois = csv.DictReader(f, delimiter='\t')
        #for (_id, _type, _geom) in aois:
        # per_gee_account = abs(old_div((opts.total-1),5))
        # start = opts.start*per_gee_account
        # if opts.start == 4:
        #   end = (opts.total-1)
        # else:
        #   end = start+(per_gee_account-1)
    
    aois_current = dates_to_run(opts.aois, data_existing) 
    # aois_current.to_csv('aois_current_metadata.csv')   
    aois_current.to_csv('/tmp/aois_current_metadata.csv') 
    if os.path.exists('/tmp/aois_current_metadata.csv'):
      print("File successfully written")
    else:
      print("Error: File not found!") 
    start = 0
    end = 1000
    i=0
    for i in range(0, len(aois_current)):
        if i >= start and i <= end:
            start_date_ls=aois_current['start_date_ls'][i].strftime("%Y-%m-%d")
            start_date_sent=aois_current['start_date_sent'][i].strftime("%Y-%m-%d")
            start_date_w=aois_current['start_date_w'][i].strftime("%Y-%m-%d")
            _id = aois_current['aoi_crop_id'][i]
            _type = aois_current['aoi_type'][i]
            _geom = aois_current['aoi_geometry'][i]
            _crop_type = int(aois_current['crop_cdl_id'][i])

            region = ee.FeatureCollection(ee.Geometry(json.loads(_geom)))
            scale = cdl.get_scale(region)
            if _type == 'field':
                region_cdl = region
                region_cdl_mask = ee.Image.constant(1).clip(region)
                acres = _get_acreage(region)
            else:
                region_cdl, region_cdl_mask, acres = _get_best_cdl_for_geom(region, _crop_type, scale)
              # forces evaluation of region from GEE to make available locally.
              # sub-optimal from a GEE perspective, which would prefer all evaluation
              # is performed within GEE, but used for now to enable some flow
              # control based on the realized object.
              # if coordinates do not have length, we didn't find any CDL overlap,
              # and do not want to compute weather.
            log.info('aoi_crop_id=%s, aoi_type=%s, crop_type=%s, scale=%s, region_cdl=%s, acres=%0.8f' % (_id, _type, _crop_type, scale, bool(region_cdl), acres))
              
            # Appending list of all aois (could just do this from aois.tsv)
            ll_2 = _id
            ll.append(ll_2)
              
            if region_cdl:
              # if 'physical' in outputs:
              #     physical_collection = get_physical_collection_for_feature(physical_images, region_cdl)
              #     physical_export = VinsightTask(physical_collection, 'physical', GC_BUCKET, MODEL_NAME, opts.execution,
              #       _crop_type, _id, opts.gdrive)
              #     physical_export.start()
              #     tasks.append(physical_export)
                if 'weather' in outputs:
                    gridmet_collection = ee.ImageCollection(GRIDMET_COLLECTION_PATH).filterDate(start_date_w, end_date)
                    weather_collection = get_weather_collection_for_feature(gridmet_collection, region_cdl)
                    weather_export = VinsightTask(weather_collection, 'weather', GC_BUCKET, MODEL_NAME, opts.execution, _crop_type, _id, opts.gdrive)
                    weather_export.start()
                    tasks.append(weather_export)
           
                if 'imagery' in outputs:
                    landsat_collection = get_landsat_collection_for_feature(landsat_collections, region_cdl, region_cdl_mask, start_date_ls, end_date)
                   #p_collection = get_sentinel_collection_for_feature(sentinel_collection, region_cdl, region_cdl_mask, start_date_sent, end_date)
                  # 
                  # innerJoin = ee.Join.inner()
                  # 
                  # filterYear = ee.Filter.equals(**{
                  #   'leftField': 'year',
                  #   'rightField': 'year'
                  #   })
                  # 
                  # Joinedimagery = innerJoin.apply(landsat_collection, p_collection, filterYear)
                  # 
                  # def cleanJoin(feature):
                  #     f1 = ee.Feature(feature.get('primary'))
                  #     f2 = ee.Feature(feature.get('secondary'))
                  #     return f1.set(f2.toDictionary())
                  # 
                  # imagery_collection = Joinedimagery.map(cleanJoin)
        
        
                    imagery_export = VinsightTask(landsat_collection, 'imagery', GC_BUCKET, MODEL_NAME, opts.execution,
                        _crop_type, _id, opts.gdrive)
                    imagery_export.start()
                    tasks.append(imagery_export)
        # elif i > end:
        #   break
        # 
        # i=i+1
                    if pd.isna(aois_current.loc[i, 'execution']):
                        if 'physical' in outputs:
                            physical_collection = get_physical_collection_for_feature(physical_images, region_cdl)
                            physical_export = VinsightTask(physical_collection, 'physical', GC_BUCKET, MODEL_NAME, opts.execution, _crop_type, _id, opts.gdrive)
                            physical_export.start()
                            tasks.append(physical_export)   
            
    # Metadata update 
    #create a new dictionary for the current run
    data_new = {}

    for aoi in ll:
        found = False
        for key in list(data_existing.keys()):
            if aoi in data_existing[key]['aoi']:
                # remove the AOI from the existing key pair
                data_existing[key]['aoi'].remove(aoi)
                if not data_existing[key]['aoi']:
                    del data_existing[key]
                found = True
                break
        if not found:
            # create a new key pair for the AOI
            new_key = lrd
            data_existing[new_key] = {
                "lastrundate": lrd_new,
                "lastpermweather": lpwd,
                "aoi": [aoi]
            }
    # create a new key pair for all AOIs in the passed list
    new_key = lrd
    data_existing[new_key] = {
        "lastrundate": lrd_new,
        "lastpermweather": lpwd,
        "aoi": ll
    }

    with open('metadata.json', 'w') as outfile:
        json.dump(data_existing, outfile, indent=2)


    monitor(tasks)
    if all([task.ee_task.status()['state'] == 'COMPLETED' for task in tasks]):
        return 0
    return 1

if __name__ == '__main__':
  ee_initialize()